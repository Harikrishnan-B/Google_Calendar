
import React from 'react';

const CalendarGrid = ({ currentDate, setShowModal, setSelectedDay, events }) => {
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  const currentDay = new Date().getDate();
  const isCurrentMonth = 
    new Date().getMonth() === currentDate.getMonth() && 
    new Date().getFullYear() === currentDate.getFullYear();

  const handleDayClick = (day) => {
    setSelectedDay(day);
    setShowModal(true);
  };

  const getEventsForDay = (day) => {
    return events.filter((event) => event.date === day);
  };

  const emptyDays = Array(firstDay).fill(null);

  return (
    <div className="mx-auto max-w-4xl shadow-2xl rounded-lg overflow-hidden bg-white">
      <div className="grid grid-cols-7 bg-gradient-to-r from-green-700 to-green-600 text-white">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
          <span key={day} className="p-3 text-center font-bold border-r border-green-500 last:border-r-0">
            {day}
          </span>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {emptyDays.map((_, index) => (
          <div key={`empty-${index}`} className="h-28 bg-gray-50 border-b border-r border-gray-200"></div>
        ))}
        {Array.from({ length: daysInMonth }, (_, index) => index + 1).map((day) => {
          const isToday = isCurrentMonth && day === currentDay;
          const dayEvents = getEventsForDay(day);
          const hasEvents = dayEvents.length > 0;
          
          return (
            <div 
              key={day} 
              className={`
                h-28 p-2 border-b border-r border-gray-200 transition-all duration-200
                ${isToday ? 'bg-green-50' : 'bg-white'} 
                hover:bg-green-50 relative group
              `}
              onClick={() => handleDayClick(day)}
            >
              <div className="flex justify-between items-start">
                <span className={`
                  ${isToday ? 'bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center' : 'text-gray-700'}
                  font-medium
                `}>
                  {day}
                </span>
                <button className="opacity-0 group-hover:opacity-100 transition-opacity text-green-600 hover:text-green-800">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
              
              <div className="mt-1 space-y-1 overflow-y-auto max-h-20 scrollbar-thin scrollbar-thumb-green-200">
                {dayEvents.map((event, index) => (
                  <div 
                    key={index} 
                    className="bg-gradient-to-r from-green-600 to-green-500 text-white p-1 rounded-md text-xs shadow-sm flex items-center"
                  >
                    <span className="w-2 h-2 bg-white rounded-full mr-1 flex-shrink-0"></span>
                    <span className="truncate">{event.title}</span>
                    {event.time && <span className="ml-auto text-green-100">{event.time}</span>}
                  </div>
                ))}
              </div>
              
              {hasEvents > 0 && (
                <div className="absolute bottom-1 right-1">
                  <span className="bg-green-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {dayEvents.length}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CalendarGrid;